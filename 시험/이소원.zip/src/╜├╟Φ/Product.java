package 시험;

//작성자 : 이소원
public abstract class Product {

	protected int price;
	protected String prdName;
	
	public abstract String sell(Object object);
	
	
}

