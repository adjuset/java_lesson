package 시험;

//작성자 : 이소원

public class ProductTest {

	public static void main(String[] args) {

		
		
		
		
	}
}

class Electronics extends Product{

	private double kwh;
	
	Electronics(){};
	
	Electronics(int price, String prdName){
		this.price = price;
		this.prdName = prdName;
	}
	
	public double power(double kwh) {
		return kwh *24 ;
	}
	
	@Override
	public String sell(Object object) {
		return String.format("묶음 상품 - %s(1set)", object);
	}
	

	@Override
	public String toString() {
		return "Electronics [kwh=" + kwh + ", price=" + price + ", prdName=" + prdName + "]";
	}

	public double getKwh() {
		return kwh;
	}

	public void setKwh(double kwh) {
		this.kwh = kwh;
	}
	
	
	
}
